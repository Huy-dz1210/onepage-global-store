import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "@/generated/prisma/client";

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

function createClient() {
  // Mặc định giống prisma.config.ts để thiếu .env vẫn chạy được với Postgres cài sẵn (user/pass: postgres)
  const connectionString = process.env.DATABASE_URL || "postgresql://postgres:postgres@localhost:5432/fintrack?schema=public";
  const adapter = new PrismaPg({ connectionString });
  return new PrismaClient({ adapter });
}

export const prisma = globalForPrisma.prisma ?? createClient();
if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
